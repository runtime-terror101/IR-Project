﻿
from flask import Flask, render_template, flash , redirect , url_for , session,request
from wtforms import Form,StringField, TextAreaField, PasswordField, validators
import re
from datetime import date
import smtplib , ssl
from passlib.hash import sha256_crypt
from numpy import genfromtxt
import joblib
from flask import send_file
from collections import defaultdict
import pandas as pd
from os import listdir
import os
from os.path import isfile, join
from nltk.tokenize import word_tokenize 
from sklearn.feature_extraction.text import TfidfVectorizer
from nltk.stem import PorterStemmer as ps
from nltk.stem import WordNetLemmatizer as wl
from nltk.corpus import stopwords
from collections import Counter
import numpy as np
import re
import math
import seaborn as sns
stopword = set(stopwords.words())
import random
from sklearn.metrics import confusion_matrix ,  precision_recall_fscore_support
from sklearn.metrics import accuracy_score
import pickle
from gensim.test.utils import common_texts
from rank_bm25 import BM25Okapi
from gensim.models.doc2vec import Doc2Vec, TaggedDocument
import pandas as pd

# from sklearn.externals import joblib 
def preprocess(sent):
    result = sent
    result = " ".join(re.split(r"[^a-zA-Z0-9\s]",result))  # removing speacial characters
    result = " ".join(result.split()) # removing white spaces
    result = re.sub(r'\d+','',result) # remove numbers
    result = re.sub(r'[^\w\s]','',result) # remove punctuation
    result = word_tokenize(result) # Tokenizing words
    result = [ word.lower() for word in result ] # Convertinbg to lower case 
#     result = [ps().stem(i) for i in result]   # Stemming 
#     result = [wl().lemmatize(i) for i in result] #lemmatize 
#     result = [word for word in result if word not in stopword and word in add_catch] # removing stopwords
    result = [word for word in result if word not in stopword] # removing stopwords
    return result

from pickle import load
tf_idf =load(open('tf_tfidf.pkl','rb'))
filesnametrain = load(open('filesnametrain.pkl','rb'))

store = Flask(__name__, template_folder='abc')

def evaluate(tf_idf , query):  # Function for evaluating the query
    ans = []
#     doc_scores = bm25.get_scores(query)
#     print(doc_scores)
#     for i in range(len(tf_idf)):
#         ans.append([filesnametrain[i] , doc_scores[i]])
#     query = Counter(query)

    for i in tf_idf:
        score = 0
        for j in query:
            score += tf_idf[i][j]
        if score:
            ans.append([filesnametrain[i] , score])
        
#     new_sentence_vectorized = model.infer_vector(query)
#     similar_sentences = model.dv.most_similar(positive=[new_sentence_vectorized] , topn = len(filestrain))
#     print(len(similar_sentences))
#     print(len(ans))
#     for i in similar_sentences:
# #         print(i)
#         ans[i[0]][1] *= i[1]
#     print(ans)
    
#     q1 =  plm.top(500 , query)
#     qrr1 = {i[0]:i[1] for i in q1}
#     for i in tf_idf:
#         score = 0
#         for j in qrr1:
#             score += arr1[i][j] * qrr1[j]
#         ans[i][1] *= score


    ans.sort(key = lambda x:-x[1])
    return [ i[0] for i in ans[:200] ]

@store.route('/')
def home():
    return render_template('home.html')

@store.route('/about')
def about():
    return render_template('about.html')

@store.route('/contact')
def contact():
    return render_template('contact.html')

@store.route('/success', methods = ['POST'])  
def success():  
    if request.method == 'POST':  
        f = request.files['file']
        query = f.read().decode('cp850')
        query = preprocess(query)
        arr = evaluate(tf_idf , query )
        print(arr)
    return render_template('result.html',len = len(arr) , fin = arr)

@store.route('/Prior_Cases/<filename>' , methods = ['GET'])
def getfile(filename):
    try:
        return send_file('./Prior_Cases/'+filename)
    except Exception as e:
        return str(e)



if __name__=='__main__':
    store.secret_key="yashraj"
    store.run(debug=True)
